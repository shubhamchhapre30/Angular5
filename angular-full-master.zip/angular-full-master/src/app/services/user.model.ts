export class User{
    token:string;
    refresh_token:string;
}