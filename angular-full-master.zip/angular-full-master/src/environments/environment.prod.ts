export const environment = {
  production: true,
  API_url:'http://localhost/schedullo/Angular',
  // API_url:'https://impdev.schedullo.com/Angular',
};
